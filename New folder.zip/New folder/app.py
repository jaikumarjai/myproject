from flask import Flask, render_template,url_for


app = Flask(__name__) 
@app.route('/home') 
def home(): 
    name='jayakumar' 
    return render_template('login.html',user_name=name)
@app.route('/<name>') 
def jaya(name): 
    #name='jayakumar' 
    return render_template('index.html',user_name=name)

@app.route('/table') 
def kumar(): 
    mark_list=[45,25,65,77,98] 
    return render_template('table.html',list=mark_list)

@app.route('/about') 
def about():  
    return render_template('about.html')

if __name__ =='__main__':  
    app.run(debug = True)  