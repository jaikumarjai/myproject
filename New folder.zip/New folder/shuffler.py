from image_shuffler import Shuffler
image = Shuffler('C:/Users/MANI MASS/Music/flask/New folder/templates/jaya.jpg')
image.shuffle(matrix=(5,5))
image.show()